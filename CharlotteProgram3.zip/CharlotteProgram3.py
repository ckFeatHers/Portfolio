#CIS-299 Py 7 March 18
#Charlotte Feathers
#chpt 5

    
#method for calculating the average of scores inputed.
def main():
    #declare variables
    score1 = 0.0
    score2 = 0.0
    score3 = 0.0
    score4 = 0.0
    score5 = 0.0
    average = 0.0

    score1 = get_score()
    #equivilant to
    #score1 = float(input('\nEnter Grade: '))
    #while score1 > 100 or score1 < 0:
    #    score1 = float(input('Not in range, try again.  '))
        
    score2 = get_score()

    score3 = get_score()

    score4 = get_score()

    score5 = get_score()


#find the average with methond
    average = calc_avg(score1, score2, score3, score4, score5)

#print display of grades

    print('\nScore\t\t', 'Numeric Score\t\t', 'Letter Grade')
    
    print('Score 1:\t\t' + format(score1, '5.1f') + '\t\t\t' + get_grade(score1))    
    print('Score 2:\t\t' + format(score2, '5.1f') + '\t\t\t' + get_grade(score2))
    print('Score 3:\t\t' + format(score3, '5.1f') + '\t\t\t' + get_grade(score3))  
    print('Score 4:\t\t' + format(score4, '5.1f') + '\t\t\t' + get_grade(score4)) 
    print('Score 5:\t\t' + format(score5, '5.1f') + '\t\t\t' + get_grade(score5))  
    
    print('Average Score:\t\t\t\t\t' + format(average, '.1f'))

#test score range
#retrieve grade from user and test range then return valid score to caller
def get_score():
    score = float(input('Enter Grade: '))
    while score > 100 or score < 0:
        score = float(input('Not in range, try again.  '))
    return score

        

def calc_avg(score1, score2, score3, score4, score5):
#calculate average
#input scores (note: use of an array & loop would be awsome)

    average = (score1 + score2 + score3 + score4 + score5)/5
    return average
       

def get_grade(score):
#evaluating score to get letter grade
#score input, return letter
    
    grade = ' '
    
    if score >= 90:
        grade = ' A'
    elif score >= 80:
        grade = ' B'
    elif score >= 70:
        grade = ' C'
    elif score >= 60:
        grade = ' D'
    else:
        grade = ' F'

    return grade

#call main to get flow started
main()
    


    
        


    

        
        



