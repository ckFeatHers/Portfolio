CREATE TABLE administrators (
    adminID  			INT 			NOT NULL 		AUTO_INCREMENT,
    emailAddress 		VARCHAR(255) 	NOT NULL,
    password 			VARCHAR(255) 	NOT NULL,
    firstName 			VARCHAR(60),
    lastName 			VARCHAR(60),
    PRIMARY KEY (adminID));
	
	
INSERT INTO administrators (adminID, emailAddress, password, firstName, lastName) VALUES
	(101, 'admin@myguitarshop.com', 'sesame', 'Admin', 'Istrator');
INSERT INTO administrators (adminID, emailAddress, password, firstName, lastName) VALUES
	(102, 'Helen.Thomas@swic.edu', 'pa55word'. 'Helen', 'Thomas');