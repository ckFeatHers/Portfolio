<?php
session_start();
require_once('model/database.php');
require_once('model/admin_db.php');

$action = filter_input(INPUT_POST, 'action');
if ($action == NULL) {
	$action = filter_input(INPUT_GET, 'action');
	if($action == NULL){
		$action = 'show_admin_menu';
	}
}

if(!isset($SESSION['is_valid_admin'])) {
	$action = 'login';
}
switch($action)
{
	case 'login':
		$email =filter_input(INPUT_POST, 'email');
		$password = filter_input(INPUT_POST, 'password');
		if (is_valid_admin_login($email, $password)) {
			$_SESSION['is_valid_admin'] = true;
			include('view/start.php');
		} else {
			$login_message = 'You must login to view this page.';
			include('view/login.php');
		}
		break;
	case 'show_admin_menu':
		include('view/admin_menu.php');
		break;
	case 'show_product_manager':
		include('view/start.php');
		break;
	case 'show_order_manager':
		include('view/order_manager.php');
		break;
	case 'logout':
	$_SESSION = array();
	session_destroy();
	$login_message = 'You have been logged out';
	include('view/login.php');
	break;
}
?>