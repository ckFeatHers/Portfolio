<?php include 'view/header.php'; ?>
<section>
    <h1>Database Error</h1>
    <p>A database error occurred.</p>
    <p class="last_paragraph">Error message: <?php echo $error_message; ?></p>
</section>
<?php include 'view/footer.php'; ?>