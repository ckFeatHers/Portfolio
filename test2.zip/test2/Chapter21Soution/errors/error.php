<?php include 'view/header.php'; ?>
<section>
    <h2>Error</h2>
    <p class="last_paragraph"><?php echo $error; ?></p>
</section>
<?php include 'view/footer.php'; ?>