<?php
require_once('../util/main.php');
require_once('../util/tags.php');
require_once('../model/database.php');
require_once('../model/part_db.php');
require_once('../model/make_db.php');

$action = filter_input(INPUT_POST, 'action');
if ($action == NULL) {
    $action = filter_input(INPUT_GET, 'action');
    if ($action == NULL) {
        $action = 'list_parts';
    }
}

switch ($action) {
    case 'list_parts':
        // get current make
        $make_id = filter_input(INPUT_GET, 'make_id', 
                FILTER_VALIDATE_INT);
        if ($make_id == NULL || $make_id === FALSE) {
            $make_id = 1;
        }                

        // get makes and parts
        $current_make = get_make($make_id);
        $makes = get_makes();
        $parts = get_parts_by_make($make_id);

        // display view
        include('part_list.php');
        break;
    case 'view_part':
        $makes = get_makes();

        // get part data
        $part_id = filter_input(INPUT_GET, 'part_id', 
                FILTER_VALIDATE_INT);
        $part = get_part($part_id);
        
        // display part
        include('part_view.php');
        break;
}
?>