<?php include '../view/header.php'; ?>
<?php include '../view/sidebar.php'; ?>
<section>
    <!-- display part -->
    <?php include '../view/part.php'; ?>
</section>
<?php include '../view/footer.php'; ?>