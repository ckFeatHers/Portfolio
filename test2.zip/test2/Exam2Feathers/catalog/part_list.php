<?php include '../view/header.php'; ?>
<?php include '../view/sidebar.php'; ?>
<section>
    <h1><?php echo $current_make['makeName']; ?></h1>
    <?php if (count($parts) == 0) : ?>
        <ul><li>There are no parts in this make.</li></ul>
    <?php else: ?>
        <ul>
        <?php foreach ($parts as $part) : ?>
        <li>
            <a href="?action=view_part&amp;part_id=<?php
                      echo $part['partID']; ?>">
                <?php echo $part['partName']; ?>
            </a>
        </li>
        <?php endforeach; ?>
        </ul>
    <?php endif; ?>
</section>
<?php include '../view/footer.php'; ?>