/*****************************************
* Creates the Dooley's Automotive database
*****************************************/
DROP DATABASE IF EXISTS dooleys_parts;
CREATE DATABASE dooleys_parts;
USE dooleys_parts;  -- MySQL command

-- create the tables
CREATE TABLE makes (
  makeID       INT(11)        NOT NULL   AUTO_INCREMENT,
  makeName     VARCHAR(255)   NOT NULL,
  PRIMARY KEY (makeID)
);

CREATE TABLE parts (
  partID         INT            NOT NULL   AUTO_INCREMENT,
  makeID        INT            NOT NULL,
  partCode       VARCHAR(10)    NOT NULL,
  partName       VARCHAR(255)   NOT NULL,
  description       TEXT           NOT NULL,
  listPrice         DECIMAL(10,2)  NOT NULL,
  discountPercent   DECIMAL(10,2)  NOT NULL   DEFAULT 0.00,
  dateAdded         DATETIME       NOT NULL,
  PRIMARY KEY (partID), 
  INDEX makeID (makeID), 
  UNIQUE INDEX partCode (partCode)
);

CREATE TABLE orders (
  orderID        INT(11)        NOT NULL   AUTO_INCREMENT,
  customerID     INT            NOT NULL,
  orderDate      DATETIME       NOT NULL,
  PRIMARY KEY (orderID)
);

CREATE TABLE administrators (
    adminID  			INT 			NOT NULL 		AUTO_INCREMENT,
    emailAddress 		VARCHAR(255) 	NOT NULL,
    password 			VARCHAR(255) 	NOT NULL,
    firstName 			VARCHAR(60),
    lastName 			VARCHAR(60),
    PRIMARY KEY (adminID));

-- insert data into the database
INSERT INTO makes VALUES
(1, 'Jaguar'),
(2, 'Porsche'),
(3, 'Ferrari'),
(4, 'Astin Martin'),
(5, 'Rolls Royce'),
(6, 'Lamborghini'),
(7, 'Alfa Romeo'),
(8, 'Miscellaneous');

INSERT INTO parts VALUES
(1, 1, '1-2689-0', 'Oil Filter - Jaguar', 'Premium quality filter for your Jaguar', '2.0', '69.00', '20190131'),
(2, 2, '2-2519-0', 'Oil Filter - Porsche', 'Premium quality filter for your Porsche', '2.0','119.00', '20190131'),
(3, 3, '3-6359-0', 'Oil Filter - Ferrari', 'Premium quality filter for your Ferrari', '2.0','117.00', '20190131'),
(4, 4, '4-3295-0', 'Oil Filter - Astin Martin', 'Premium quality filter for your Astin Martin', '2.0','89.99', '20190131'),
(5, 5, '5-6958-0', 'Oil Filter - Rolls Royce', 'Premium quality filter for your Rolls Royce', '2.0','129.00','20190131'),
(6, 6, '6-6597-0', 'Oil Filter - Lamborghini', 'Premium quality filter for your Jaguar', '1.5','145.00', '20190131'),
(7, 7, '7-2698-0', 'Oil Filter - Alfa Romeo', 'Premium quality filter for your Alfa Romeo', '2.0','79.99', '20190131'),
(8, 8, '8-1112-0', 'Premium Motor Oil/qt', 'High quality oil for your high performance car', '0.0', '39.99', '20190131'),
(9, 1, '1-6287-1', 'Air Filter - Jaguar', 'Premium quality filter for your Jaguar', '2.0','49.99', '20190131'),
(10, 2, '2-2894-1', 'Air Filter - Porsche', 'Premium quality filter for your Porsche', '2.0','39.99', '20190131'),
(11, 3, '3-3598-1', 'Air Filter - Ferrari', 'Premium quality filter for your Ferrari', '2.0','67.00', '20190131'),
(12, 4, '4-8579-1', 'Air Filter - Astin Martin', 'Premium quality filter for your Astin Martin', '2.0','49.99', '20190131'),
(13, 5, '5-5847-1', 'Air Filter - Rolls Royce', 'Premium quality filter for your Rolls Royce', '2.0','79.00', '20190131'),
(14, 6, '6-4561-1', 'Air Filter - Lamborghini', 'Premium quality filter for your Jaguar', '1.5','75.00', '20190131'),
(15, 7, '7-8536-1', 'Air Filter - Alfa Romeo', 'Premium quality filter for your Alfa Romeo', '2.0','39.99','20190131'),
(16, 8, '8-2568-0', 'Premium Brake Fluid', 'High quality brake fluid for you high performance car', '0.0','29.89', '20190131'),
(17, 8, '8-6598-0', 'Premium Transmission Fluid', 'High quality transmission fluid for you high performance car', '0.0','15.99', '20190131'),
(18, 1, '1-5526-2', 'Upper Radiator Hose- Jaguar', 'Premium quality radiator hose for your Jaguar', '2.0','269.00', '20190131'),
(19, 8, '8-8522-0', 'Premium Anti-Freeze', 'High quality anti-freeze for you high performance car', '0.0','35.69', '20190131'),
(20, 1, '1-5527-2', 'Lower Radiator Hose - Jaguar', 'Premium quality radiator hose for your Jaguar', '2.0','399.00', '20190131'),
(21, 2, '2-5526-2', 'Upper Radiator Hose- Porsche', 'Premium quality radiator hose for your Porsche', '2.0','239.00', '20190131'),
(22, 3, '3-5526-2', 'Upper Radiator Hose- Ferrari', 'Premium quality radiator hose for your Ferrari', '2.0','169.00', '20190131'),
(23, 4, '4-5526-2', 'Upper Radiator Hose- Astin Martin', 'Premium quality radiator hose for your Astin Martin', '2.0','269.29', '20190131'),
(24, 5, '5-5526-2', 'Upper Radiator Hose- Rolls Royce', 'Premium quality radiator hose for your Rolls Royce', '2.0','289.60', '20190131'),
(25, 6, '6-5526-2', 'Upper Radiator Hose- Lamborghini', 'Premium quality radiator hose for your Lamborghini', '2.0','229.00', '20190131'),
(26, 7, '7-5526-2', 'Upper Radiator Hose- Alfa Romeo', 'Premium quality radiator hose for your Alfa Romeo', '2.0','219.99', '20190131'),
(27, 2, '2-5527-2', 'Lower Radiator Hose - Porsche', 'Premium quality radiator hose for your Porsche', '2.0','319.79', '20190131'),
(28, 3, '3-5527-2', 'Lower Radiator Hose - Ferrari', 'Premium quality radiator hose for your Ferrari', '2.0','399.00', '20190131'),
(29, 4, '4-5527-2', 'Lower Radiator Hose - Astin Martin', 'Premium quality radiator hose for your Astin Martin', '2.0','229.00', '20190131'),
(30, 5, '5-5527-2', 'Lower Radiator Hose - Rolls Royce', 'Premium quality radiator hose for your Rolls Royce', '2.0','299.28', '20190131'),
(31, 6, '6-5527-2', 'Lower Radiator Hose - Lamborghini', 'Premium quality radiator hose for your Lamborghini', '2.0','365.00', '20190131'),
(32, 7, '7-5527-2', 'Lower Radiator Hose - Alfa Romeo', 'Premium quality radiator hose for your Alfa Romeo', '2.0','539.00', '20190131');

INSERT INTO administrators (adminID, emailAddress, password, firstName, lastName) VALUES
(1, 'admin@myguitarshop.com', '6a718fbd768c2378b511f8249b54897f940e9022', 'Admin', 'User'),
(2, 'joel@murach.com', '971e95957d3b74d70d79c20c94e9cd91b85f7aae', 'Joel', 'Murach'),
(3, 'mike@murach.com', '3f2975c819cefc686282456aeae3a137bf896ee8', 'Mike', 'Murach');

-- create the users and grant priveleges to those users
GRANT SELECT, INSERT, DELETE, UPDATE
ON dooleys_parts.*
TO mgs_user@localhost
IDENTIFIED BY 'pa55word';

GRANT SELECT
ON parts
TO mgs_tester@localhost
IDENTIFIED BY 'pa55word';

