<?php
function get_parts_by_make($make_id) {
    global $db;
    $query = 'SELECT * FROM parts
              WHERE makeID = :make_id
              ORDER BY partID';
    try {
        $statement = $db->prepare($query);
        $statement->bindValue(':make_id', $make_id);
        $statement->execute();
        $result = $statement->fetchAll();
        $statement->closeCursor();
        return $result;
    } catch (PDOException $e) {
        $error_message = $e->getMessage();
        display_db_error($error_message);
    }
}

function get_parts() {
    global $db;
    $query = 'SELECT * FROM parts ORDER BY partID';
    try {
        $statement = $db->prepare($query);
        $statement->execute();
        $result = $statement->fetchAll();
        $statement->closeCursor();
        return $result;
    } catch (PDOException $e) {
        $error_message = $e->getMessage();
        display_db_error($error_message);
    }
}

function get_part($part_id) {
    global $db;
    $query = 'SELECT *
              FROM parts
              WHERE partID = :part_id';
    try {
        $statement = $db->prepare($query);
        $statement->bindValue(':part_id', $part_id);
        $statement->execute();
        $result = $statement->fetch();
        $statement->closeCursor();
        return $result;
    } catch (PDOException $e) {
        $error_message = $e->getMessage();
        display_db_error($error_message);
    }
}

function add_part($make_id, $code, $name, $description,
        $price, $discount_percent) {
    global $db;
    $query = 'INSERT INTO parts
                 (makeID, partCode, partName, description,
                  listPrice, discountPercent, dateAdded)
              VALUES
                 (:make_id, :code, :name, :description, :price,
                  :discount_percent, NOW())';
    try {
        $statement = $db->prepare($query);
        $statement->bindValue(':make_id', $make_id);
        $statement->bindValue(':code', $code);
        $statement->bindValue(':name', $name);
        $statement->bindValue(':description', $description);
        $statement->bindValue(':price', $price);
        $statement->bindValue(':discount_percent', $discount_percent);
        $statement->execute();
        $statement->closeCursor();

        // Get the last part ID that was automatically generated
        $part_id = $db->lastInsertId();
        return $part_id;
    } catch (PDOException $e) {
        $error_message = $e->getMessage();
        display_db_error($error_message);
    }
}

function update_part($part_id, $code, $name, $description,
                        $price, $discount_percent, $make_id) {
    global $db;
    $query = 'UPDATE Parts
              SET partName = :name,
                  partCode = :code,
                  description = :description,
                  listPrice = :price,
                  discountPercent = :discount_percent,
                  makeID = :make_id
              WHERE partID = :part_id';
    try {
        $statement = $db->prepare($query);
        $statement->bindValue(':name', $name);
        $statement->bindValue(':code', $code);
        $statement->bindValue(':description', $description);
        $statement->bindValue(':price', $price);
        $statement->bindValue(':discount_percent', $discount_percent);
        $statement->bindValue(':make_id', $make_id);
        $statement->bindValue(':part_id', $part_id);
        $row_count = $statement->execute();
        $statement->closeCursor();
        return $row_count;
    } catch (PDOException $e) {
        $error_message = $e->getMessage();
        display_db_error($error_message);
    }
}

function delete_part($part_id) {
    global $db;
    $query = 'DELETE FROM parts WHERE partID = :part_id';
    try {
        $statement = $db->prepare($query);
        $statement->bindValue(':part_id', $part_id);
        $row_count = $statement->execute();
        $statement->closeCursor();
        return $row_count;
    } catch (PDOException $e) {
        $error_message = $e->getMessage();
        display_db_error($error_message);
    }
}
?>