<?php
function get_makes() {
    global $db;
    $query = 'SELECT * FROM makes
              ORDER BY makeID';
    try {
        $statement = $db->prepare($query);
        $statement->execute();
        $result = $statement->fetchAll();
        $statement->closeCursor();
        return $result;
    } catch (PDOException $e) {
        display_db_error($e->getMessage());
    }
}

function get_make($make_id) {
    global $db;
    $query = 'SELECT * FROM makes
              WHERE makeID = :make_id';
    try {
        $statement = $db->prepare($query);
        $statement->bindValue(':make_id', $make_id);
        $statement->execute();
        $result = $statement->fetch();
        $statement->closeCursor();
        return $result;
    } catch (PDOException $e) {
        display_db_error($e->getMessage());
    }
}

function add_make($name) {
    global $db;
    $query = 'INSERT INTO makes (makeName)
              VALUES (:name)';
    try {
        $statement = $db->prepare($query);
        $statement->bindValue(':name', $name);
        $statement->execute();
        $statement->closeCursor();

        // Get the last part ID that was automatically generated
        $make_id = $db->lastInsertId();
        return $make_id;
    } catch (PDOException $e) {
        $error_message = $e->getMessage();
        display_db_error($error_message);
    }
}

function update_make($make_id, $name) {
    global $db;
    $query = '
        UPDATE makes
        SET makeName = :name
        WHERE makeID = :make_id';
    try {
        $statement = $db->prepare($query);
        $statement->bindValue(':name', $name);
        $statement->bindValue(':make_id', $make_id);
        $statement->execute();
        $statement->closeCursor();
    } catch (PDOException $e) {
        $error_message = $e->getMessage();
        display_db_error($error_message);
    }
}

function delete_make($make_id) {
    global $db;
    $query = 'DELETE FROM makes WHERE makeID = :make_id';
    try {
        $statement = $db->prepare($query);
        $statement->bindValue(':make_id', $make_id);
        $statement->execute();
        $statement->closeCursor();
    } catch (PDOException $e) {
        $error_message = $e->getMessage();
        display_db_error($error_message);
    }
}

function get_part_count($make_id) {
    global $db;
    $query = 'SELECT COUNT(*) AS partCount
              FROM parts
              WHERE makeID = :make_id';
    $statement = $db->prepare($query);
    $statement->bindValue(':make_id', $make_id);
    $statement->execute();
    $result = $statement->fetchAll();
    $statement->closeCursor();

    $part_count = $result[0]['partCount'];
    return $part_count;
}

?>