<?php
require_once('util/main.php');
require_once('util/tags.php');
require_once('model/database.php');
require_once('model/part_db.php');
require_once('model/make_db.php');

// Get all makes
$makes = get_makes();

// Set the featured part IDs in an array
$part_ids = array(1, 7, 9);
// Note: You could also store a list of featured parts in the database

// Get an array of featured parts from the database
$parts = array();
foreach ($part_ids as $part_id) {
    $part = get_part($part_id);
    $parts[] = $part;   // add part to array
}

// Display the home page
include('home_view.php');
?>