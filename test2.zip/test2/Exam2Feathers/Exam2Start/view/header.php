<!DOCTYPE html>
<html>    
<!-- the head section -->
<head>
    <title>Dooley's Auto Shop</title>
    <link rel="stylesheet" type="text/css"
          href="<?php echo $app_path ?>main.css" />
</head>

<!-- the body section -->
<body>
<header>
    <h1>Dooley's Auto Shop</h1>
</header>
<main>
            