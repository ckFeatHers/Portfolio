
</main>
<footer>
    <p id="copyright">
        &copy; <?php echo date("Y"); ?> Dooley's Auto Shop, Inc.
    </p>
</footer>
</body>
</html>