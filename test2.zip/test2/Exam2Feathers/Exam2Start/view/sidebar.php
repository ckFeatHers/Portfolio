<aside>
    <!-- These links are for testing only.
         Remove them from a production application. -->
    <h2>Links</h2>
    <ul>
        <li>
            <a href="<?php echo $app_path; ?>">Home</a>
        </li>
        <li>
            <a href="<?php echo $app_path . 'admin'; ?>">Admin</a>
        </li>
    </ul>
    <h2>Makes</h2>
    <ul>
        <!-- display links for all makes -->
        <?php foreach ($makes as $make) : ?>
        <li>
            <a href="<?php echo $app_path . 'catalog' . 
                '?action=list_parts' .
                '&amp;make_id=' . $make['makeID']; ?>">
                <?php echo $make['makeName']; ?>
            </a>
        </li>
        <?php endforeach; ?>
        <li>&nbsp;</li>
    </ul>
</aside>
