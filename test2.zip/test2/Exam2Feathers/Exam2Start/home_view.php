<?php include 'view/header.php'; ?>
<?php include 'view/sidebar.php'; ?>
<section>
    <h1>Featured Parts</h1>
    <p>Dooley's Auto Shop has a great selection of oil and filters 
	   for many makes and models. And we're constantly adding more 
	   to give you the best selection possible!
    </p>
    <table>
    <?php foreach ($parts as $part) :
        // Get part data
        $list_price = $part['listPrice'];
        $discount_percent = $part['discountPercent'];
        $description = $part['description'];
        
        // Calculate unit price
        $discount_amount = round($list_price * ($discount_percent / 100.0), 2);
        $unit_price = $list_price - $discount_amount;

        // Get first paragraph of description
        $description_with_tags = add_tags($description);
        $i = strpos($description_with_tags, "</p>");
        $description_paragraph = substr($description_with_tags, 3, $i-3);
    ?>
        <tr>
            <td class="part_info_cell">
                <p>
                    <a href="catalog?action=view_part&amp;part_id=<?php 
                              echo $part['partID']; ?>">
                        <?php echo $part['partName']; ?>
                    </a>
                </p>
                <p>
                    <b>Your price:</b>
                    $<?php echo number_format($unit_price, 2); ?>
                </p>
                <p>
                    <?php echo $description_paragraph; ?>
                </p>
            </td>
        </tr>
    <?php endforeach; ?>
    </table>
</section>
<?php include 'view/footer.php'; ?>