<?php
require_once('../../util/main.php');
require_once('../../util/tags.php');
require_once('../../model/database.php');
require_once('../../model/part_db.php');
require_once('../../model/make_db.php');

$action = filter_input(INPUT_POST, 'action');
if ($action == NULL) {
    $action = filter_input(INPUT_GET, 'action');
    if ($action == NULL) {
        $action = 'list_parts';
    }
}

switch ($action) {
    case 'list_parts':
        $make_id = filter_input(INPUT_GET, 'make_id', 
                FILTER_VALIDATE_INT);
        if ($make_id === FALSE) {
            $make_id = 1;
        }                
        $current_make = get_make($make_id);
        $makes = get_makes();
        $parts = get_parts_by_make($make_id);
        include('part_list.php');
        break;
    case 'view_part':
        $makes = get_makes();
        $part_id = filter_input(INPUT_GET, 'part_id', 
                FILTER_VALIDATE_INT);
        $part = get_part($part_id);
        include('part_view.php');
        break;
    case 'delete_part':
        $part_id = filter_input(INPUT_POST, 'part_id', 
                FILTER_VALIDATE_INT);
        $make_id = filter_input(INPUT_POST, 'make_id', 
                FILTER_VALIDATE_INT);
        delete_part($part_id);
        
        // display part list for the current make
        header("Location: .?make_id=$make_id");
        break;
    case 'show_add_edit_form':
        $part_id = filter_input(INPUT_GET, 'part_id', 
                FILTER_VALIDATE_INT);
        if ($part_id == NULL) {
            $part_id = filter_input(INPUT_POST, 'part_id', 
                    FILTER_VALIDATE_INT);
        }
        $part = get_part($part_id);
        $makes = get_makes();
        include('part_add_edit.php');
        break;
    case 'add_part':        
        $make_id = filter_input(INPUT_POST, 'make_id', 
                FILTER_VALIDATE_INT);
        $code = filter_input(INPUT_POST, 'code');
        $name = filter_input(INPUT_POST, 'name');
        $description = filter_input(INPUT_POST, 'description');
        $price = filter_input(INPUT_POST, 'price', FILTER_VALIDATE_FLOAT);
        $discount_percent = filter_input(INPUT_POST, 'discount_percent');        

        if ($make_id === FALSE || 
                $code == NULL || $name == NULL || $description == NULL ||
                $price === FALSE || $discount_percent === FALSE) {            
            $error = 'Invalid part data.
                      Check all fields and try again.';
            include('../../errors/error.php');
        } else {
            $makes = get_makes();
            $part_id = add_part($make_id, $code, $name,
                    $description, $price, $discount_percent);
            $part = get_part($part_id);
            include('part_view.php');
        }
        break;
    case 'update_part':
        $part_id = filter_input(INPUT_POST, 'part_id', 
                FILTER_VALIDATE_INT);
        $make_id = filter_input(INPUT_POST, 'make_id', 
                FILTER_VALIDATE_INT);
        $code = filter_input(INPUT_POST, 'code');
        $name = filter_input(INPUT_POST, 'name');
        $description = filter_input(INPUT_POST, 'description');
        $price = filter_input(INPUT_POST, 'price', FILTER_VALIDATE_FLOAT);
        $discount_percent = filter_input(INPUT_POST, 'discount_percent');        

        if ($part_id === FALSE || $make_id === FALSE ||
                $code === NULL || $name === NULL || $description === NULL ||
                $price === FALSE || $discount_percent === FALSE) {            
            $error = 'Invalid part data.
                      Check all fields and try again.';
            include('../../errors/error.php');
        } else {
            $makes = get_makes();
            update_part($part_id, $code, $name, $description,
                           $price, $discount_percent, $make_id);
            $part = get_part($part_id);
            include('part_view.php');
        }
        break;                
        
    case 'list_makes':
        $makes = get_makes();
        include('make_list.php');
        break;
    case 'add_make':
        $name = filter_input(INPUT_POST, 'name');

        // Validate inputs
        if ($name === NULL) {
            $error = "Invalid make name. Check name and try again.";
            include('view/error.php');
        } else {
            add_make($name);
            header('Location: .?action=list_makes');  // display the Make List page
        }
        break;
    case 'delete_make':
        $make_id = filter_input(INPUT_POST, 'make_id', 
                FILTER_VALIDATE_INT);

        $part_count = get_part_count($make_id);
        if ($part_count > 0) {
            display_db_error("This make can't be deleted because it contains parts.");
        } else {
            delete_make($make_id);
            header('Location: .?action=list_makes');      // display the Make List page
        }
        break;
}
?>