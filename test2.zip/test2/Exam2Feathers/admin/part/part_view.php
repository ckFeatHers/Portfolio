<?php include '../../view/header.php'; ?>
<?php include '../../view/sidebar_admin.php'; ?>

<section>
    <h1>Part Manager - View Part</h1>
    
    <!-- display part -->
    <?php include '../../view/part.php'; ?>

    <!-- display buttons -->
    <div class="last_paragraph">
        <form action="." method="post" id="edit_button_form">
            <input type="hidden" name="action" value="show_add_edit_form"/>
            <input type="hidden" name="part_id"
                   value="<?php echo $part['partID']; ?>" />
            <input type="hidden" name="make_id"
                   value="<?php echo $part['makeID']; ?>" />
            <input type="submit" value="Edit Part" />
        </form>
        <form action="." method="post" >
            <input type="hidden" name="action" value="delete_part"/>
            <input type="hidden" name="part_id"
                   value="<?php echo $part['partID']; ?>" />
            <input type="hidden" name="make_id" 
                   value="<?php echo $part['makeID']; ?>" />
            <input type="submit" value="Delete Part"/>
        </form>
    </div>
</section>
<?php include '../../view/footer.php'; 