<?php include '../../view/header.php'; ?>
<?php include '../../view/sidebar_admin.php'; ?>
<?php
if (isset($part_id)) {
    $heading_text = 'Edit Part';
} else {
    $heading_text = 'Add Part';
}
?>
<section>
    <h1>Part Manager - <?php echo $heading_text; ?></h1>
    <form action="index.php" method="post" id="add_edit_part_form">
        <?php if (isset($part_id)) : ?>
            <input type="hidden" name="action" value="update_part" />
            <input type="hidden" name="part_id"
                   value="<?php echo $part_id; ?>" />
        <?php else: ?>
            <input type="hidden" name="action" value="add_part" />
        <?php endif; ?>
            <input type="hidden" name="make_id"
                   value="<?php echo $part['makeID']; ?>" />

        <label>Make:</label>
        <select name="make_id">
        <?php foreach ($makes as $make) : 
            if ($make['makeID'] == $part['makeID']) {
                $selected = 'selected';
            } else {
                $selected = '';
            }
        ?>
            <option value="<?php echo $make['makeID']; ?>" <?php
                      echo $selected ?>>                
                <?php echo $make['makeName']; ?>
            </option>
        <?php endforeach; ?>
        </select><br>

        <label>Code:</label>
        <input type="text" name="code"
               value="<?php echo htmlspecialchars(
                       $part['partCode']); ?>"><br>

        <label>Name:</label>
        <input type="text" name="name" 
               value="<?php echo htmlspecialchars(
                       $part['partName']); ?>"><br>

        <label>List Price:</label>
        <input type="text" name="price" 
               value="<?php echo $part['listPrice']; ?>"><br>

        <label>Discount Percent:</label>
        <input type="text" name="discount_percent" 
               value="<?php echo $part['discountPercent']; ?>"><br>

        <label>Description:</label>
        <textarea name="description" 
                  rows="10"><?php echo htmlspecialchars(
                            $part['description']); ?></textarea><br>

        <label>&nbsp;</label>
        <input type="submit" value="Submit">
    </form>
    
    <div id="formatting_directions">
        <h2>How to format the Description entry</h2>
        <ul>
            <li>Use two returns to start a new paragraph.</li>
            <li>Use an asterisk to mark items in a bulleted list.</li>
            <li>Use one return between items in a bulleted list.</li>
            <li>Use standard HMTL tags for bold and italics.</li>
        </ul>
    </div>
</section>
<?php include '../../view/footer.php'; ?>