<?php include '../../view/header.php'; ?>
<?php include '../../view/sidebar_admin.php'; ?>
<section>
    <h1>Part Manager - Make List</h1>
    <table id="make_table" >
        <tr>
            <th class="left" >Name</th>
            <th>&nbsp;</th>
        </tr>
        <?php foreach ($makes as $make) : ?>
        <tr>
            <td>
                <?php echo htmlspecialchars($make['makeName']); ?>
            </td>
            <td>
                <form class="delete_part_form"
                      action="index.php" method="post">
                    <input type="hidden" name="action" value="delete_make">
                    <input type="hidden" name="make_id"
                           value="<?php echo $make['makeID']; ?>">
                    <input type="submit" value="Delete">
                </form>
            </td>
        </tr>
        <?php endforeach; ?>
    </table>
    <br>

    <h2>Add Make</h2>
    <form id="add_make_form"
          action="index.php" method="post">
        <input type="hidden" name="action" value="add_make">

        
        <input type="input" name="name">
        <input type="submit" value="Add">
    </form>

    <p class="last_paragraph">
        <a href="index.php?action=list_parts">List Parts</a>
    </p>

</section>
<?php include '../../view/footer.php'; ?>