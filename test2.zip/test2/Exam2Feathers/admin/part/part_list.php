<?php include '../../view/header.php'; ?>
<?php include '../../view/sidebar_admin.php'; ?>
<section>
    <h1>Part Manager - List Parts</h1>
    <p>To view, edit, or delete a part, select the part.</p>
    <p>To add a part, select the "Add Part" link.</p>
    <?php if (count($parts) == 0) : ?>
        <ul><li>There are no parts for this make.</li></ul>
    <?php else : ?>
        <h2><?php echo $current_make['makeName']; ?></h2>
        <ul>
            <?php foreach ($parts as $part) : ?>
            <li>
                <a href="?action=view_part&amp;part_id=<?php
                          echo $part['partID']; ?>">
                    <?php echo $part['partName']; ?>
                </a>
            </li>
            <?php endforeach; ?>
        </ul>
    <?php endif; ?>

    <h2>Links</h2>
    <p><a href="index.php?action=show_add_edit_form">Add Part</a></p>
    <p class="last_paragraph">
        <a href="index.php?action=list_makes">List Makes</a>
    </p>    
</section>
<?php include '../../view/footer.php'; ?>