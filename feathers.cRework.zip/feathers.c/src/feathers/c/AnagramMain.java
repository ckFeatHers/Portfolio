package feathers.c;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

// My apologies on the lateness and failure to complete all tasks.
// CIS 287 Charlotte Feathers Fall 18 Ch 18 Recursion

public class AnagramMain {

	public static void main(String[] args) {
		
		String userStr = "";
		Scanner input = new Scanner(System.in);
		System.out.printf("Welcome to anagram!%n");
		
		System.out.printf("%nEnter word to anagram(-1 to exit): ");
		userStr = input.nextLine();
		
		while (!userStr.equals("-1"))
			{	
				while(!userStr.isEmpty()) {
					
				Anagram ana = new Anagram(userStr);
		
				System.out.printf("Anagrams for %s are %n", userStr);
				ana.grams();
				
				List<String> result = new LinkedList<>();
				result = ana.words;
								
				for(String w : result) {	
				System.out.printf("%d\t %s%n", result.indexOf(w)+1 ,w);				
				}
				
				System.out.printf("%nEnter word to anagram(-1 to exit): ");
				userStr = input.nextLine();
				if (userStr.equals("-1")) {break;}
				}
			}	
		System.out.printf("%nGood bye!%n");	
		input.close();
	}

}
