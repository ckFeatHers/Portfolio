/**
 * 
 */
package feathers.c;
import java.util.LinkedList;
import java.util.List;

/**
 * @author Feathers.c
 *
 */
public class Anagram {
	protected String str;
	protected int max;
	protected List<String> words = new LinkedList<>();
	/**
	 * input string
	 */
	
	public Anagram(String string) {
		str = string;
		max = str.length();		
	}
	
	//initiates evaluation;
	public void grams() {
		words.add(str);
		gram(str);			
	}
	
	public String gram(String s) {	
		
		if (str.length() == 1 ) {
			return s;
		}
		else if(s.length() == 2) {
			s = swap2(s);
			if (str.length() == 2) {
			words.add(s);				
			}
			return s;
		}
		else 
		{
			words.add(s);
			s = swap2(s);			
			String tr= s.substring(1, s.length());
			String newWord = str.substring(0, max-s.length()+1) + tr;
			words.add(newWord);
			return gram(tr);
			}								
	}
			
	public String swap2(String s) {
		String s1 = s.substring(0,1);
		String s2 = s.substring(1);
		return (s2 + s1);
	}		

	
}
