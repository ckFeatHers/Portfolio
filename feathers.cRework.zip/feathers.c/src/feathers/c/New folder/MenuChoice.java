package feathers.c;

public class MenuChoice {
		protected static ChoiceRaw one = new ChoiceRaw();
		protected static ChoiceShow two = new ChoiceShow();
		protected static ChoiceSummary five = new ChoiceSummary();
		protected static ChoiceExit six = new ChoiceExit();
		
		
	public static Choice getChioce() {
		Choice ch;
		Input in = new Input();
		int c = in.getInput();
		switch (c) {
			case (1):
				ch = ChoiceRaw.process();
				break;
			case (2):
				ch = ChoiceShow.process();
				break;
			case(3):
				ch = ChoiceShow.process(DEPT);
				break;
			case(4):
				ch = ChoiceShow.process(QTY);
				break;
			case(5):
				ch = ChoiceSummary.process();
				break;
			case(6): 
				ch = ChoiceExit.process();
				break;
			default:
				break;
		}
		return ch;

	}

}
