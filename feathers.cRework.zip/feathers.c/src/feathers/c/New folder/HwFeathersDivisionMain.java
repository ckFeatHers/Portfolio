package feathers.c;
import java.util.Scanner;

public class HwFeathersDivisionMain {

	public static void main(String[] args) {
		System.out.printf("Welcome to division!%n%n");
		
		Scanner scanner = new Scanner(System.in);		

		boolean validNumeInput = false;
		double numeInput = 0;			
		//start validation for numerator		
		while (!validNumeInput) {
			
			System.out.printf("Please enter a numerator:  ");
			String numeInputValue = scanner.nextLine();			
				try {
					numeInput = Double.parseDouble(numeInputValue);		
					//start validation for denominator		
						boolean validDenomInput = false;
						while (!validDenomInput) {						
							System.out.printf("Please enter a denominator:  ");
							String denoInputValue = scanner.nextLine();
									
							try {
								double denoInput = Double.parseDouble(denoInputValue);		
								if (denoInput != 0 ) {			
									double results = numeInput / denoInput;						
									System.out.printf("%.6f / %.6f = %.6f ", numeInput, denoInput, results);							
									validNumeInput = true;
									validDenomInput = true;
									}
								else {
									System.out.printf("Denominator cannot be 0.  Try again.%n");					
									}
								}
							catch (NumberFormatException e) {
								System.out.printf("The value for denominator " + '"' + "%s" + '"' + " is not numeric. Try again.%n", denoInputValue);				
								}
						}
						//end validation for denominator					
					}
				catch (NumberFormatException e) {
					System.out.printf("The value for numerator " + '"' + "%s" + '"' + " is not numeric. Try again.%n", numeInputValue);
			}
			//end of validation for numerator
		}		
		System.out.printf("%n%nGood Bye!");

	}
/*
*/
}
