package feathers.c;

import java.nio.file.Paths;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

public class TempAnalysisMain {

	static List<Integer> tempList = new ArrayList<>();

	public TempAnalysisMain() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		System.out.printf("%n  Welcome to temperature analysis!%n%n");
		
		Map<Integer, Integer> mapTemps = new HashMap<>();
		
		float total = 0;
		float sum = 0;
		
		//try (loadTempChart()) {	}
		try (
		Scanner scanner = new Scanner(Paths.get("temperatures.dat"));) {
			
			while (scanner.hasNext()) {
				String line = scanner.nextLine();
				line = line.trim();
				
				Integer Id = Integer.parseInt(line);
				Integer count;				
				System.out.printf("");
				if (mapTemps.containsKey(Id)) {
						count = mapTemps.get(Id) + 1;
						mapTemps.replace(Id, count);
					} else {
						count = 1;	
						mapTemps.put(Id, count);
						tempList.add(Id);
					}
				total++;
				sum += Id;
				Collections.sort(tempList);
				}   // end while for read file
			
			if (total == 0) {sum = 1;} //to avoid div by zero
			}  // end try for read		
		catch (Exception e)
		{
			System.out.printf("Error: "+ e);
		}
	
		int low = getLow();
		int high = getHigh(); 
		float average =  sum/total;
		int IdCountMax = getCountTempMax(mapTemps);
		int IdCountMin = getCountTempMin(mapTemps);
		
		System.out.printf("  There are %.0f total temperature data values.%n%n", total);
		System.out.printf("  The coldest temperature is %d.%n%n", low);
		System.out.printf("  The warmest temperature is %d.%n%n", high);
		System.out.printf("  The average temperature is %.2f%n%n", average);
		System.out.printf("  Frequency of each temperature: %n");
		System.out.printf("  TEMP\tCOUNT%n");
		System.out.printf("  ====\t=====%n");
		
		for(int l : tempList) {
		System.out.printf("  %4d\t%5d%n", l,  mapTemps.get(l));			
		}
		System.out.printf("%n");
		System.out.printf("  The smallest, least frequent temperature is %d.%n", IdCountMin);		
		System.out.printf("  The largest, most frequent temperature is %d.%n", IdCountMax);
		
		System.out.printf("%n%n  Good bye!");
	}	


	private static int getHigh() {
		int h; 
		h = Collections.max(tempList);
		return h;
	}

	private static int getLow() {
		int lowest = Collections.min(tempList);
		return lowest;
	}

	private static Integer getCountTempMin(Map<Integer, Integer> m) {
		
		Integer cMin;
		Integer tMin;
		List<Integer> countMin = new LinkedList<>();
		List<Integer> minTemp = new LinkedList<>();
		List<Integer> tempAtMinCount = new LinkedList<>();		
		
		for (Integer id : tempList) {
			countMin.add(m.get(id));
			minTemp.add(id);
		}		
		
		cMin = Collections.min(countMin);
		
		for (int i=0; i < countMin.size(); i++) {
			if (countMin.get(i).equals(cMin)) {
			  tempAtMinCount.add(minTemp.get(i));
			}
		}
				
			tMin = Collections.min(tempAtMinCount);	
		
			return tMin;
	}

	public static int getCountTempMax(Map<Integer, Integer> m) {
		
		Integer cMax;
		Integer tMax;
		List<Integer> maxCount = new LinkedList<>();
		List<Integer> maxTemps = new LinkedList<>();
		List<Integer> tempAtMaxCount = new LinkedList<>();
		
		for (Integer t : tempList) {
			maxCount.add(m.get(t));
			maxTemps.add(t);
		}	
		
		cMax = Collections.max(maxCount);
		
		for (int i=0; i < tempList.size(); i++) {
			if (maxCount.get(i).equals(cMax)) {
			  tempAtMaxCount.add(maxTemps.get(i));
			}
		}
		tMax = Collections.max(tempAtMaxCount);
		
		return tMax;
	}
}
			
