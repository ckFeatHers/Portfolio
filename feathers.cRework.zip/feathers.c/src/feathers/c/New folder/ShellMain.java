package feathers.c;
import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

// Feathers.c week3 homework due 9/11/18

// Question starting on line 77. Which solution is most efficient?
// Question starting on line 100. Do I need a scanner object?

public class ShellMain {

	public ShellMain() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) throws IOException  {
		// TODO Auto-generated method stub
		boolean begin = true;
		Scanner scan = new Scanner(System.in);
		
		System.out.printf("Welcome to Shell Homework!%n");
		
		while(begin) {
			System.out.printf("%nPrompt> ");
			String userIn = scan.nextLine().trim();

			// test for input			
			if (userIn.isEmpty()){
				System.out.print("Execute 'help' for more information.%n");
				continue;
			}
			
			// split up user Input into the separate words
			String[] userInput = userIn.split(" ");			
			String command = userInput[0];
			
			if ("exit".equals(command) && userInput.length <2) {
				begin = false;		// could use break here too. 
			}			
			else if ("help".equals(command) && userInput.length <2) {
				helpMenu();
				continue;				
			}
			else if ("dir".equals(command)) {

				String userDir = "";				
				
				if(userInput.length == 2) {
					userDir = userInput[1];
					showPath(userDir);
				}
				else if(userInput.length == 1) {
					userDir = ".";
					showPath(userDir);
				}
				else {
					System.out.printf("ERROR: Unkown path");
				}
				
				}	
				
			else if ("show".equals(userIn) && userInput.length <= 1) {						
						System.out.printf("ERROR: The [file] parameter is missing.  Execute 'help' for more information.%n");				
					}							
		
			else if ("show".equals(command) && userInput.length == 2) {		
						String userFilePath = userInput[1];						
						showFileContents(userFilePath);			
					}			
			else
			{
				System.out.printf(
						"Unknown command \"%s\"", userIn );
			}
/*
 *Known faults: if file contains spaces, split will cause error
 * 		  solution1: test userInput array for '\' (or '/' incase using mac) and 
 * 					combine rest of array with loop
 * 		  solution2: truncate userInput string for command and use rest for path/file test. 
 * 					Do I need string builder for this?
 * 		  solution3: loop userInput array starting at index 1 and rest of array for valid use with 
 * 					the show command. Will need to add file name at start of each content group.
 * 
 */
	}
		
		System.out.printf("%nGood Bye!");
		scan.close();
	}
	
	public static void helpMenu() {
		Scanner scan = new Scanner(System.in);
		System.out.printf("COMMANDS:%n");
		System.out.printf("  help\t\tList of commands%n");
		System.out.printf("  dir [path]\tList the contents of directory%n");
		System.out.printf("  show file \tShow the contents of file%n");
		System.out.printf("  exit\t\tExit the shell%n");
/*
 * Does a scanner need to be opened in this?  I was assuming so, however when I for got it in the following
 * two methods, no issues occurred with 'System.out'.  
 */
	}
	
	public static void showPath(String d) {

		Path userPath = Paths.get(d);						
			
		if (!Files.exists(userPath)) {
				System.out.printf("Directory does not exist: \"%s\"%n", d);
		}
		else if (Files.isDirectory(userPath)) {
			try {
				System.out.printf("Directory of \"%s\"%n", Paths.get(d).toAbsolutePath());
				DirectoryStream<Path> children;
				children = Files.newDirectoryStream(userPath);	
				for (Path p : children) {
					if(Files.isDirectory(p)) {		
						System.out.printf("%s\t\t%s%n", "d", p.getFileName());
					} else { 
						System.out.printf("  %s%s\t%s%n", " ", (Files.size(p)+ " bytes"), p.getFileName()); 	
					}
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else {
			if (Files.exists(userPath)) {
				System.out.printf("This is not a directory: \"%s\"%n", Paths.get(d).toAbsolutePath());
			}else {
				System.out.printf("This directory does not exist: \"%s\"%n", d);
			}
		}		
	}
	
	public static void showFileContents(String userFile) {
		
		Path showPath = Paths.get(userFile);	
		// see if file exist
		
		if (Files.isDirectory(showPath)) {
			System.out.printf("This is not a file: \"%s\". Execute 'help' for more information. %n", userFile);			
		}
		else if (Files.exists(showPath)){
			try (Scanner scanner = new Scanner(showPath)) {
				while(scanner.hasNext()) {
					String line = scanner.nextLine();
					System.out.println(line);
				}								
			}
			catch (Exception e) {
				System.out.printf("ERROR: File not read: \"%s\"%nException: %s", e);								
			}
				System.out.printf("%n");							
			}
		else {
			System.out.printf("ERROR: File does not exits: \"%s\"%n", userFile);			
		}
	}

}

/*
 * Introduce program: ""
 * 
 * prompt> help dir show exit
 *  
 * help = lists commands known
 * dir = list directory name "repeat input", d for sub directory with name, and byte size for file with its name
 * 		error1: "Path does not exist: "repeat input"
 * 		error2: "ERROR: Path is not a directory: "repeat input"
 * show = SHOW: "repeat input", next line show contents
 * 		error1: "ERROR: The [file] parameter is missing.  Execute 'help' for more information.
 * 		error2: "ERROR: File does not exits: "repeat input".
 * exit = exit on -1 and say "Good bye!"
 * 
 * if none of the four are entered
 * 		error: "Unknown command "repeat input"
 * 
 * added: show error - not a file(if a dir)
 * 		  help error - command not recognized if extra words behind it
 * 		  exit error - command not recognized if extra words behind it
 * 
 * Question was moved to above... 		 
 * Known faults: if file contains spaces, split will cause error
 * 		  solution1: test userInput array for '\' (or '/' incase using mac) and 
 * 					combine rest of array with loop
 * 		  solution2: truncate userInput string for command and use rest for path/file test. 
 * 					Do I need string builder for this?* 
 *
 * */