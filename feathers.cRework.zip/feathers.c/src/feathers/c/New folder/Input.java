package feathers.c;

import java.util.Scanner;

public class Input  {
	Scanner scanner = new Scanner(System.in);

	

	public int getInput() {
		int c = 0;

		while (c == 0) {
		System.out.print("Selection: ");
		String s = scanner.nextLine();	
		s = s.trim();		
		
		if (s.length() == 1) {
			try {
			c = Integer.parseInt(s);			
				if (c < 1 || c > 6 ) {
			System.out.printf("Oops, try again. %n");
			c = 0;
				} // end if range
				else {
					return c;
				
			} // end if empty
			} catch (Exception e) {
				System.out.printf("Oops, try again. %n");
			}
		} // end try
		else {
			System.out.printf("Oops, try again. %n");
			c = 0; } // end fianlly
		} // end while
		return c;		
		}
		
}