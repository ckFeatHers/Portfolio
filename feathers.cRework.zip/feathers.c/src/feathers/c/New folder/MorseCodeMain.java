package feathers.c;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class MorseCodeMain {

	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		boolean exit = false;
		Matcher mDashDot;
		Matcher mAlpha;
		Pattern pDashDot;	
		Pattern pAlpha;
		
		System.out.printf("Welcome to translator!%n%n");
		
		
		while (!exit) {
			System.out.printf("Enter text to translate(Enter -1 to exit):  ");
			String userInput = scanner.nextLine().trim();

			String language;
			boolean validMorse;
			String results = "";
			
			pDashDot = Pattern.compile("[.-]");
			pAlpha = Pattern.compile("[abcdefghijklmnopqrstuvwxyz]", Pattern.CASE_INSENSITIVE);
			mDashDot = pDashDot.matcher(userInput);
			mAlpha = pAlpha.matcher(userInput);
			
// If -1 exit 						
			if ("-1".equals(userInput)){
				exit = true;
				continue;
				}
			else
			{
				exit = false;
			}
									
// Determine Language
		
			if (mDashDot.find() && !mAlpha.find()) {	
				language = "Morse Code";	
				validMorse = true;
				}
			else {			
				language = "English";
				validMorse = false;
				}	
			
// Read tokens
			if(validMorse) {
			
			String[] wordsInCode = userInput.split("   ");	
				StringBuilder alpha = new StringBuilder();				
								
			for (int i=0; i<wordsInCode.length; i++) {	
				String[] letterInWord = wordsInCode[i].split(" ");
			
				for (String code : letterInWord) {
					if (code.equals(".-")) 			{alpha.append("A");}
					else if (code.equals("-...")) 	{alpha.append("B");}
					else if (code.equals("-.-.")) 	{alpha.append("C");}					
					else if (code.equals("-..")) 	{alpha.append("D");}
					else if (code.equals(".")) 		{alpha.append("E");}
					else if (code.equals("..-.")) 	{alpha.append("F");}
					else if (code.equals("--.")) 	{alpha.append("G");}
					else if (code.equals("....")) 	{alpha.append("H");}
					else if (code.equals("..")) 	{alpha.append("I");}
					else if (code.equals(".---")) 	{alpha.append("J");}
					else if (code.equals("-.-"))	{alpha.append("K");}
					else if (code.equals(".-..")) 	{alpha.append("L");}
					else if (code.equals("--")) 	{alpha.append("M");}
					else if (code.equals("-.")) 	{alpha.append("N");}
					else if (code.equals("---")) 	{alpha.append("O");}
					else if (code.equals(".--.")) 	{alpha.append("P");}
					else if (code.equals("--.-")) 	{alpha.append("Q");}
					else if (code.equals(".-.")) 	{alpha.append("R");}
					else if (code.equals("...")) 	{alpha.append("S");}					
					else if (code.equals("-")) 		{alpha.append("T");}
					else if (code.equals("..-")) 	{alpha.append("U");}
					else if (code.equals("...-")) 	{alpha.append("V");}
					else if (code.equals(".--")) 	{alpha.append("W");}		
					else if (code.equals("-..-")) 	{alpha.append("X");}		
					else if (code.equals("-.--")) 	{alpha.append("Y");}
					else if (code.equals("--..")) 	{alpha.append("Z");}		
					else if (code.equals(".----")) 	{alpha.append("1");}		
					else if (code.equals("..---")) 	{alpha.append("2");}		
					else if (code.equals("...--")) 	{alpha.append("3");}		
					else if (code.equals("....-")) 	{alpha.append("4");}
					else if (code.equals(".....")) 	{alpha.append("5");}		
					else if (code.equals("-....")) 	{alpha.append("6");}
					else if (code.equals("--...")) 	{alpha.append("7");}	
					else if (code.equals("---..")) 	{alpha.append("8");}	
					else if (code.equals("----.")) 	{alpha.append("9");}	
					else if (code.equals("-----")) 	{alpha.append("0");}	
					else {							alpha.append("?");}
			
					}// end for loop for letters in words
					alpha.append(" ");
				results = alpha.toString();
				}// end of for loop for word in phrase			
		
			}//end if
			else 
			{
				userInput = userInput.toUpperCase();
			String[] tokens = userInput.split(" ");	
			String wordResult = "";

			StringBuilder morse = new StringBuilder();		
			
			for (String token : tokens) {		
				char[] word = token.toCharArray();
			

				for (char letter : word ) {					
					if (letter == 'A') {morse.append(".- ");}
					else if (letter == 'B') {morse.append("-... ");}
					else if (letter == 'C') {morse.append("-.-. ");}					
					else if (letter == 'D') {morse.append("-.. ");}
					else if (letter == 'E') {morse.append(". ");}
					else if (letter == 'F') {morse.append("..-. ");}
					else if (letter == 'G') {morse.append("--. ");}
					else if (letter == 'H') {morse.append(".... ");}
					else if (letter == 'I') {morse.append(".. ");}
					else if (letter == 'J') {morse.append(".--- ");}
					else if (letter == 'K') {morse.append("-.- ");}
					else if (letter == 'L') {morse.append(".-.. ");}
					else if (letter == 'M') {morse.append("-- ");}
					else if (letter == 'N') {morse.append("-. ");}
					else if (letter == 'O') {morse.append("--- ");}
					else if (letter == 'P') {morse.append(".--. ");}
					else if (letter == 'Q') {morse.append("--.- ");}
					else if (letter == 'R') {morse.append(".-. ");}
					else if (letter == 'S') {morse.append("... ");}
					else if (letter == 'T') {morse.append("- ");}
					else if (letter == 'U') {morse.append("..- ");}
					else if (letter == 'V') {morse.append("...- ");}
					else if (letter == 'W') {morse.append(".-- ");}		
					else if (letter == 'X') {morse.append("-..- ");}		
					else if (letter == 'Y') {morse.append("-.-- ");}
					else if (letter == 'Z') {morse.append("--.. ");}
					else if (letter == '1') {morse.append(".---- ");}
					else if (letter == '2') {morse.append("..--- ");}
					else if (letter == '3') {morse.append("...-- ");}
					else if (letter == '4') {morse.append("....- ");}
					else if (letter == '5') {morse.append("..... ");}
					else if (letter == '6') {morse.append("-.... ");}
					else if (letter == '7') {morse.append("--... ");}
					else if (letter == '8') {morse.append("---.. ");}
					else if (letter == '9') {morse.append("----. ");}
					else if (letter == '0') {morse.append("----- ");}
					else {morse.append("? ");}
					}//end of for char loop	
				morse.append("  "); 
				wordResult = morse.toString();						
				}//end of for string				
			results = results + wordResult ;			
			}//end else 				
					
				// Output Translation
			System.out.printf("Detected Language: %s%n%n %s%n%n", language, results);
		}// end while
				
			System.out.printf("%nGood Bye!");	
			scanner.close();
	} // main
			
} // class

	

/*
 * Welcome 'Welcome to translator'
 * 
 * Ask and Allow user to input string for translation
 * 'Enter text to translate(Enter -1 to exit)'
 * 
 * Validate and Test User Input for English or Morse Code
 * 
 * Convert English to Morse
 * Convert Morse to English
 * Unknown charaters should be represented with '?'
 * 
 * Output results to screen
 * Prompt for next entry
 * 
 * Exiting(on -1 entry) say 'Good bye!'
*/