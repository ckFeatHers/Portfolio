package feathers.c;
import java.util.Scanner;


public class RecursionMain {


	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner input = new Scanner(System.in);
		
		System.out.printf("Welcome to anagram%n");
		

		System.out.printf("Enter a string");
		
		
		
		
		
	}

}
