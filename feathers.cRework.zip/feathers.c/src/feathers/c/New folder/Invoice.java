package feathers.c;

import java.io.PrintStream;
import java.math.BigDecimal;
import java.text.DecimalFormat;

public class Invoice {
	private Integer id;
	private String department;
	private String description;
	private Integer quantity;
	// private BigDecimal price;
	
	private Double dprice;

	public Invoice() {
/*		// TODO Auto-generated constructor stub
		Integer id = 0;
		String department = "None";
		String description = "N/A";
		Integer quantity = 0;
		BigDecimal price = null;
	*/
		}

	public Invoice(Integer i, String dept, String desc, Integer q, Double dp) {
		id = i;
		department = dept;
		description = desc;
		quantity = q;
		dprice = dp;
		
	}
/*	
	public Invoice(Integer i, String dept, String desc, Integer q, BigDecimal p) {
		Integer id = i;
		String department = dept;
		String description = desc;
		Integer quantity = q;
		BigDecimal price = p;
	}
*/
	public Integer getId() {
		return id;
	}
	
	public void setId(Integer i) {
		this.id = i;
	}
	
	public String getDept() {
		return department;
	}
	
	public void setDept(String dept) {
		department = dept;
	}
	
	public String getDesc() {
		return description;
	}
	
	public void setDesc(String desc) {
		description = desc;
	}
	
	public Integer getQuantity() {
		return quantity;
	}
	
	public void setQuantity(Integer q) {
		quantity = q;
	}
	/*	
	public BigDecimal getPrice() {
		return price;
	}
	

	public void setPrice(BigDecimal p) {
		price = p;
	}
	*/
	public Double getPriceD() {
		return dprice;
	}
	
	public void priceD(Double dp) {
		dprice = dp;
	}
	/*
	public int getSold() {
		return quantity;
	}*/
	
	public void printFormA() {
	 	System.out.printf("%-5d%-15s%-30s%4d$%9.2f%n%n", getId(), getDept(), getDesc(), getQuantity(), getPriceD());	
	}
	
	@Override
	public String toString() {
		String summary = getId() +"\t" + getDept() + "\t" + getDesc() + "\t" + getQuantity() + "\t" + getPriceD(); 
		return summary;
	}
}
