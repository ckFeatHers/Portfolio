package feathers.c;

import java.nio.file.Paths;
import java.text.DecimalFormat;
import java.util.Arrays;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.omg.Messaging.SyncScopeHelper;

public class InvoiceMain {

	public static void main(String[] args) throws Exception {
//		DecimalFormat df = new DecimalFormat("#,##0.00");
//		Scanner input = new Scanner(System.in);
		
		// welcome
		System.out.printf("Welcome to invoice!%n");
		
		 // create holder; read file; add to holder

		List<Invoice> invoices = new LinkedList<>();	
 		DecimalFormat df = new DecimalFormat("$#,##0.00");	 
		
		 try (Scanner reading = new Scanner(Paths.get("invoices.dat"))) 
		 {
			 while(reading.hasNext()) 
			 {
				 String lineOfInvoice = reading.nextLine().trim();
				 
				 String[] tokens = lineOfInvoice.split("\t");
				 
				 Integer id = Integer.parseInt(tokens[0].trim());
				 
				 String department = tokens[1];
				 String description = tokens[2];
				 Integer quantity = Integer.parseInt(tokens[3].trim());
				 //BigDecimal price = df.tokens[4].trim();
				 Double price = Double.parseDouble(tokens[4].trim());
	 
				 Invoice inv = new Invoice(id, department, description, quantity, price); 
			 
				 invoices.add(inv);
			 }		 			 
		 }
//Testing output:

 		 Input into = new Input();
		 int choice = 0;
		 
		 while (choice != 6) {
			 showMenu();
			 
			 choice = into.getInput();	
			 
			 switch (choice) {
			 	 case 1:
			 		 System.out.printf("%nRaw Data%n%n");
			 		 // raw data
			 		invoices.stream().forEach(System.out::println);	
			 		 break;
			 	 case 2:
			 		 System.out.printf("%nInvoices by Default%n%n");
			 		 showLabel();
			 		 //show data
				          invoices.forEach(i ->
				 	 System.out.printf("%-5s%-15s%-30s%4s%9s%n"
				 				,i.getId().toString()
				 				,i.getDept()
				 				,i.getDesc()
				 				,i.getQuantity().toString()
				 				,df.format(i.getPriceD()).toString()));
			 		 break;
			 	 case 3:
			 		 System.out.printf("%nInvoices by Department%n%n");
			 		 //show data by Department
			 		 showLabel();			 	
			 		 invoices.stream()
			 		 		 .sorted(Comparator.comparing(Invoice::getDept))
			 		 		 .forEach(i-> System.out.printf("%-5s%-15s%-30s%4s%9s%n"
				 				,i.getId().toString()
				 				,i.getDept()
				 				,i.getDesc()
				 				,i.getQuantity().toString()
				 				,df.format(i.getPriceD()).toString()));
			 		 break;
			 	 case 4:
			 		 System.out.printf("%nInvoices by Quantity%n%n");
			 		 //show data by Quantity
			 		 showLabel();			 	
			 		 invoices.stream()
			 		 		 .sorted(Comparator.comparing(Invoice::getQuantity))
			 		 		 .forEach(i-> System.out.printf("%-5s%-15s%-30s%4s%9s%n"
				 				,i.getId().toString()
				 				,i.getDept()
				 				,i.getDesc()
				 				,i.getQuantity().toString()
				 				,df.format(i.getPriceD()).toString()));
			 		 break;
			 	 case 5: 
			 		 Map<String, List<Invoice>> xxx = 
			 		 				invoices.stream().collect(Collectors.groupingBy(Invoice::getDept));
			 		
			 		 System.out.printf("%nDepartment Summary%n");
			 		 //show data summary by department

			 		 Function<Invoice, String> byDept = Invoice::getDept;
			 		 Function<Invoice, Integer> byQuantity = Invoice::getQuantity;
			 		 
			 		Map<String, Long> invSoldbyDept = invoices.stream()
			 				 								  .collect(Collectors.
			 				 										   groupingBy(Invoice::getDept,
			 				 										   Collectors.counting()));			 		
			 		invSoldbyDept
			 					 .forEach(
			 				(department, count) -> System.out.printf("%n%s%n\tSold: %d", 
			 													department, count));
/*			 		
			 		System.out.printf("%n\tSold: %d\t\tTotal: %n", 
			 				invoices.stream()
			 						  .sorted()
			 						  .mapToInt(Invoice::getQuantity)
			 						  .sum());			 							 	 
	*/		 						
			 		 break;
			 	 case 6:
			 		 //exit
			 		 break;
			 	default:
			 		break;			 		
			 }  // switch	
			 
		 }		// while
		 
		 System.out.printf("%nGood bye!");
	}			// class
	
	public static void showMenu() {
		System.out.printf("%nMain Menu%n");
		System.out.printf("\t1. Show raw data%n"
				+ "\t2. Show invoices%n"
				+ "\t3. Show invoices by DEPT%n"
				+ "\t4. Show invoices by QTY%n"
				+ "\t5. Show department summary%n"
				+ "\t6. EXIT%n%n"
				);
	}
	
	public static void showLabel() {
		 System.out.printf("%-5s%-15s%-30s%4s%9s%n", "ID", "DEPT", "DESCRIPTION", "QTY", "PRICE");
		 System.out.printf("%-5s%-15s%-30s%4s%9s%n", 
				 "====", 
				 "==============", 
				 "=============================", 
				 "====",
				 "========");
	}

}
/*, invoices.stream()
	 						  .sorted(Compartor.comparing(Invoice::getDept))
	 						  .mapToDouble(Invoices::getPriceD)
	 						  .sum()
	 						  .getAsDouble();*/