$(document).ready(function() {

	styleCgsTable();
	
	// 9B  Collect missed lessons
	$("button#hw9B").on("click", function() {
	
		let x = $("form").serializeArray();
		$.each(x, function(i, field){
			$("#moments").append("  " + field.name + ":  " + field.value + "   ");	
		});
		$("#moments").append("<br>");		
	});

		//9C Get class roster for each year in level one
	$("button#hw9C1").on("click", function() {
		getRoster("y1");
	});		
	$("button#hw9C2").on("click", function() {
		getRoster("y2");
	});			
	$("button#hw9C3").on("click", function() {
		getRoster("y3");
	});	

		
	$("h5").on("click", function() {	   
		let listID = $(this).attr("class");
		onOffBars(listID);	
	});	

	// 9A Liturgical Calender API  		
	$("button#hw9A").on("click", function() {	
		
		 $.ajax({
			 url: "http://calapi.inadiutorium.cz/api/v0/en/calendars/default/today", 
			 type: "GET",
			 success: function(data){
				$("span#homework9").text(" ");
				$("span#homework9").append("The Liturgical Calender is currently in the time of " + data.season + ".");
			},
			error: function(data) {
				alert("An error has occured in api");
		 }
	});
  }); 
	

});	

		
function getRoster(y) {
	let roster;
	
	if(y === "y1") {
		roster = "names1.json";
	}	
	else if(y === "y2") {
		roster = "names2.json";
	}
	else if(y === "y3") {
		roster = "names3.json";
	} 
	else {
		roster = "names.json";
	}	
	
	$.getJSON( roster, function( data ) {
		let list = [];	
		$.each(	data,  function( key, val ) {	
			if(key === "instructor") {
				list.push("<li id='" + key + "'>Guide: " + val + "</li>");		
			} else {				
				list.push("<li id='" + key + "'>" + val + "</li>");		  
			}
		});			
		$("ul#y1c19").html(list.join(""));			
	});		
}
		
function onOffBars(x) {	
	if (x == "third") {
		$("li#mind p").toggle("ofshow");
	} else if (x == "fourth") {
		$("li#soul div").toggle("ofshow");
	} else if(x == "fifth") {
		$("li#create p").toggle("ofshow");
	} else {
	// no change needed;
	}		
}

function styleCgsTable() {
	$("table th").css("color", "black");
	$("table tr:even").css("background-color", "aliceblue");
	$("table tr:odd").css("background-color", "#feee92");	
}

function assignment6B() {
	$("span").css("color","midnightblue");
	$("span:first").css("color","magenta");
	$("span:last").css("color","blue");
}

