$(document).ready(function() {	

//<!-- Assignment #7 Mouse Enter and Leave actions		
	$("input").on("mouseenter", function() {
		let thisID = $(this).attr("id");
		backgroundColorChange(thisID,"#cbf5bc");
	});
	
	$("input").on("mouseleave", function() {
		let thisID = $(this).attr("id");
		backgroundColorChange(thisID,"#d3dcf8");
	});


//<!-- Assignment #7 Show item Clicked	
	$("input").on("click", function() {	
		let inputID = $(this).attr("id");
		showBoozeAge(inputID);	
	});	
	
});
	
function choiceYorN(choice) {
	$("div#age").append(choice);
	$("img#choice").css("float","center").show();
}
	

function showBoozeAge(e) {	
	
	if (e == "over21") {
		let y = '<img id="choice" src="images/choice1.jpg" height="150" alt="Is the Next Question">'
			colorChange("#age", "#208000");	
			$("div#age h3").html("&nbsp;&nbsp;Welcome over 21!").show();			
			$("input:lt(2)").hide();
			$("input:gt(1)").show();
			choiceYorN(y);
	} 
	else if (e == "under21") {	
			let n = '<img id="choice" src="images/choice2.jpg" height="150" alt="Sad Face">';
			colorChange("#age", "#800020");
			$("div#age h3").html("Please return when you are 21.").show();
			$("input").hide();
			choiceYorN(n);
	} 	
	else if (e == "BEER") {
			let title = "Family Tradition of&nbsp;&nbsp;"+e;
			let picTitle = "Brewing SheBrew Style";
			

			colorChange("#BEER", "#208000");
			colorChange("#BOURBON", "darkgrey");			
			$("#BEER").css("fontWeight","bold");
			$("img#choice").hide();			
			$("div#age h3").html(title).show();	
						
			$("div#booze h3").html(picTitle);
			$("#booze").show();
			$("div#carousel").hide();
			$("div#slideshow").show();
		//show beer pictures
			slideBeer();
	} 	
	else if (e == "BOURBON") {
			let title = "Family Tradition of&nbsp;&nbsp;" + e;
			let divTitle = "Rich Bourbon Playground";	
			
			$("img#choice").hide();
			colorChange("#BEER", "darkgrey");
			colorChange("#BOURBON", "#208000");				
			$("#BOURBON").css("fontWeight","bold");			
			$("div#age h3").html(title).show();	
						
			$("div#booze h3").html(divTitle);
			$("#booze").show();
			$("div#slideshow").hide();
			$("div#carousel").show();
				//show bourbon picture
			carouselBourbon();
	} else {
		// no change
	}
}
	
function colorChange(e, c) {
	$(e)[0].style.color = c;	
}

function backgroundColorChange(e, c) {
	let selectorID = "#" + e;
//	alert("backgroundColorChange "+ e +" and "+ c);
	$(selectorID)[0].style.backgroundColor = c;	
}

function slideBeer() {

	let nextSlide = $("#slides img:first-child");
	let nextCaption;
	let nextSlideSource;
		
	// start slide show
    timer1 = setInterval(
        function () {   
        	$("#caption").fadeOut(2000);
        	$("#slide").fadeOut(2000,
           		function () {
           	     	if (nextSlide.next().length == 0) {
						nextSlide = $("#slides img:first-child");
					}
					else {
						nextSlide = nextSlide.next();
					}
					nextSlideSource = nextSlide.attr("src");
					nextCaption = nextSlide.attr("alt");
					$("#slide").attr("src", nextSlideSource).fadeIn(2000);					
					$("#caption").text(nextCaption).fadeIn(2000);
				}
			);    // end callback
		}, 
		6000);
}

function carouselBourbon() {
	
	let size = 300;
	let totalSize = 1500;		// also in #images width in css
	var slider = $("#images");                     // slider = ul element
	var leftProperty, newleftProperty;
							
	$("#right_button").click(function() { 
		// get value of current left property
		leftProperty = parseInt(slider.css("left"));
		// determine new value of left property
		if (leftProperty - size <= -totalSize) {
			newLeftProperty = -40; }
		else {
			newLeftProperty = leftProperty - size; }
		// use the animate function to change the left property
		slider.animate( {left: newLeftProperty}, 1000);
	});  // end click
	
	// the click event handler for the left button
	$("#left_button").click(function() {
		// get value of current right property
		leftProperty = parseInt(slider.css("left"));
		
		// determine new value of left property
		if (leftProperty < 0) {
			newLeftProperty = leftProperty + size;
		}
		else {
			newLeftProperty = -40;
		}
		
		// use the animate function to change the left property
		slider.animate( {left: newLeftProperty}, 1000);				
	});  // end click	
}	

/* 

//			$("#booze p").last().show();
//			$("div#slideShow").first().show();
//			$("div#age").html(imageChoice).show();

			$("div#carousel caption").text($("img#slide").attr("alt"));

<main>
    <h1>Fishing Slide Show</h1>
    <h2 id="caption">Casting on the Upper Kings</h2>
    <img id="slide" src="images/casting1.jpg" alt="">
    <div id="slides"> 
        <img src="images/casting1.jpg" alt="Casting on the Upper Kings">
        <img src="images/casting2.jpg" alt="Casting on the Lower Kings">
        <img src="images/catchrelease.jpg" alt="Catch and Release on the Big Horn">
        <img src="images/fish.jpg" alt="Catching on the South Fork">
        <img src="images/lures.jpg" alt="The Lures for Catching">
    </div>
</main>


		$("div#booze").toggle().show();	
				 
		$("ul#hob").html(list.join("")).show();
		
		$("button#hw4C").remove();

	
<!-- Assignment #4A TextColorChange
	$("span").click(function(){
	
	let e = $(this).attr("id");	
	
	if (e == "1") {
		} else if (e == "2") {	
		} else {
			colorChange("#3", 'magenta');	
		}
	});			

		$("li:first h5").click(function() {
			$("p#ofbody").toggle("ofshow");
			$("button#hw4C").toggle("ofshow");
			$("li:first ul").toggle("ofshow");
		});	 
		
	$("h5.prog").click(function() {
		$("p#ofheart").toggle("ofshow");	
	});	
	
	$("h5.data").click(function() {
		$("p#ofmind").toggle("ofshow")});	
	
	$("h5.webdes").click(function() {
		$("p#ofsoul").toggle("ofshow");	
	});	
	
	$("h5.webdev").click(function() {
		$("p#ofcreate").toggle("ofshow");	
	});		


	
//<!-- Assignment #4C GetHobbies 	

	$("button#hw4C").on("click", getHobbies);	


});	
*/
